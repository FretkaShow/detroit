mLib.Addons["mlogs"] = {
	name = "mLogs",
	key = "mlogs",
	uid = "76561198189926795",
	hid = "cc341ae98130246bf84812348aadfdef37618040c8697a010db3e1ad69075702"
}